--USE FIRST

USE MASTER

DROP DATABASE dbOregonLibrary

CREATE DATABASE dbOregonLibrary

USE dbOregonLibrary


CREATE TABLE BORROWER
(
CardNo INT Primary Key NOT NULL,
Name varchar(150) Null,
[Address] varchar(150) NULL,
Phone Varchar(15)
)

SELECT * FROM BORROWER

CREATE TABLE LIBRARY_BRANCH
(
BranchID INT Primary Key NOT NULL,
BranchName varchar(150) Null,
[Address] varchar(150) NULL,
)

SELECT * FROM LIBRARY_BRANCH

CREATE TABLE PUBLISHER
(
PublisherName varchar(150) Primary Key NOT NULL,
[Address] varchar(150) NULL,
Phone varchar(15)
)

SELECT * FROM PUBLISHER


CREATE TABLE BOOKS
(
BookID INT Primary Key NOT NULL,
Title varchar(150) NULL,
PublisherName Varchar(150) Foreign Key REFERENCES PUBLISHER(PublisherName) NOT NULL,
)

SELECT * FROM BOOKS


CREATE TABLE BOOK_COPIES
(
BookID INT Foreign Key REFERENCES BOOKS(BookID) NOT NULL,
BranchID INT Foreign Key REFERENCES LIBRARY_BRANCH(BranchID) NOT NULL,
Number_Of_Copies INT NOT Null
)

SELECT * FROM BOOK_COPIES

CREATE TABLE BOOK_LOANS
(
BookID INT Foreign Key REFERENCES BOOKS(BookId) NOT NULL,
BranchID INT Foreign Key REFERENCES LIBRARY_BRANCH(BranchID) NOT NULL,
CardNo INT Foreign Key REFERENCES BORROWER(CardNo) NOT NULL,
DateOut DATE NOT NULL,
--DateDue DATE NOT NULL
)


CREATE TABLE BOOK_AUTHORS
(
BookID INT Foreign Key REFERENCES BOOKS(BookID) NOT NULL,
AuthorName varchar(150) Null
)

SELECT * FROM BOOK_AUTHORS

